### Beschreibung

Kurze Beschreibung des Bugs.

### Schritte zum Reproduzieren

1. Schritt 1
1. Schritt 2

### Fehlermeldungen oder Ausschnitte Konsolen Logs
<!-- Da Builds archiviert werden, die relevanten Log Abschnitte hier einfügen -->

```
org.jenkinsci.plugins.scriptsecurity.sandbox.RejectedAccessException: Scripts not permitted to use method hudson.model.User getAllProperties
	at org.jenkinsci.plugins.scriptsecurity.sandbox.whitelists.StaticWhitelist.rejectMethod(StaticWhitelist.java:175)
	at org.jenkinsci.plugins.scriptsecurity.sandbox.groovy.SandboxInterceptor.onMethodCall(SandboxInterceptor.java:137)
	at org.kohsuke.groovy.sandbox.impl.Checker$1.call(Checker.java:155)
	at org.kohsuke.groovy.sandbox.impl.Checker.checkedCall(Checker.java:159)
	at com.cloudbees.groovy.cps.sandbox.SandboxInvoker.methodCall(SandboxInvoker.java:17)
```

### Links

* [Job Link](https://cje2.prod.zkb.ch/job/1455-jenkins/job/zkb-pipeline-library-dev/job/dev/71/console)