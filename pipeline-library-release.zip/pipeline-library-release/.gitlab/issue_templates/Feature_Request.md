### Beschreibung
Kurze Beschreibung des gewünschten Features und dessen Use Case.

### Pull Request Checklist
#### Wie wurde getested?

Beschreibe hier wie die neue Funktionalität getestet wurde.

#### Pipeline Link

Eine Pipeline mit der geforkten Version der shared lib kann hier gefunden werden:

https://cje123.prod.zkb.ch/job/<some-group>/job/my-pipeline-lib-test/job/my-new-feature

