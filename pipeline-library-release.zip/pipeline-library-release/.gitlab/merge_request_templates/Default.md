# Summary

(Summarize the merge request)

# How I tested my changes

(Outline how you tested your changes...)

# Checklist

- [ ] I've tested my changes
- [ ] The documentation of this repository is up-to-date
- [ ] The [pipeline-examples](https://gitlab.prod.zkb.ch/1455-jenkins/pipeline-examples) are up-to-date or not affected by my changes
- [ ] The [ZKB Jenkins User Guide](https://spcollab.prod.zkb.ch/themen/ContinuousIntegration/Wiki/Seiten/Jenkins%20User%20Guide.aspx) is up-to-date or not affected by my changes
- [ ] My code confirms to the [Groovy Style Guide](http://groovy-lang.org/style-guide.html)
