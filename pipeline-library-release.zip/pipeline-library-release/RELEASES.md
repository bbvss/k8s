# Release Notes ZKB Global Jenkins Pipeline Library

## Pipeline Library 1.2.2

* :sparkles: Add parameter for [mavenPipeline](vars/mavenPipeline.md) and [gradlePipeline](vars/gradlePipeline.md) to specify the main development branch


## Pipeline Library 1.2.1

* :mega: A complete CI pipeline for Java Maven projects [mavenPipeline](vars/mavenPipeline.md)
* :mega: A complete CI pipeline for Java Gradle projects [gradlePipeline](vars/gradlePipeline.md)
* :mega: New step  [runSonarAnalysis](vars/runSonarAnalysis.md)


## Pipeline Library 1.2.0

* :sparkles: New [PipelineHelper](src/ch/zkb/jenkins/pipeline/lib/PipelineHelper.md) methods to work with Nexus artifacts 
  * [getDownloadUrl](src/ch/zkb/jenkins/pipeline/lib/PipelineHelper.md#getdownloadurl)
  * [getVersionsAsChoiceParam](src/ch/zkb/jenkins/pipeline/lib/PipelineHelper.md#getversionsaschoiceparam)
  * [getVersionsForMavenArtifact](src/ch/zkb/jenkins/pipeline/lib/PipelineHelper.md#getversionsformavenartifact)
* :exclamation: Deprecated [gitChangelogContainsCommentPattern](src/ch/zkb/jenkins/pipeline/lib/PipelineHelper.md#gitchangelogcontainscommentpattern) 
* :exclamation: Deprecated [gitChangelogContainsFile](src/ch/zkb/jenkins/pipeline/lib/PipelineHelper.md#gitchangelogcontainsfile) 
* Documentation improvements


## Pipeline Library 1.1.1

* :sparkles: New step [readGradleProperty](vars/readGradleProperty.md) e.g. to read the version of a Gradle project


## Pipeline Library 1.1.0

* :sparkles: Add parameter for [performMavenRelease](vars/performMavenRelease.md) step to pass additional arguments to maven
* :sparkles: New step [gitCheckoutBranch](vars/gitCheckoutBranch.md)
* :sparkles: New step [gitCommit](vars/gitCommit.md)
* :sparkles: New step [gitCreateTag](vars/gitCreateTag.md)

