package ch.zkb.jenkins.pipeline.lib

import com.cloudbees.groovy.cps.NonCPS
import groovy.json.JsonSlurper
import hudson.model.Cause.UserIdCause
import hudson.model.User
import hudson.plugins.git.GitChangeSet
import hudson.plugins.git.GitChangeSetList
import hudson.triggers.TimerTrigger.TimerTriggerCause

class PipelineHelper {

    @SuppressWarnings("unused")
    static def getScmExtensions(Map params = [:]) {
        String referenceRepoLocation = params.get('referenceRepo', null)
        Boolean cleanBeforeCheckout = params.get('cleanBeforeCheckout', true)

        def scmExtensions = [[$class: 'PruneStaleBranch']]

        if (referenceRepoLocation != null) {
            scmExtensions += [[$class: 'CloneOption', reference: referenceRepoLocation]]
        }

        if (cleanBeforeCheckout) {
            scmExtensions += [[$class: 'CleanBeforeCheckout']]
        }

        return scmExtensions
    }

    @SuppressWarnings("unused")
    static boolean isNotTimerTriggered(currentBuild) {
        // rawBuild is of type http://javadoc.jenkins-ci.org/hudson/model/Run.html
        return currentBuild.rawBuild.getCause(TimerTriggerCause) == null
    }

    @SuppressWarnings("unused")
    static boolean isTimerTriggered(currentBuild) {
        // rawBuild is of type http://javadoc.jenkins-ci.org/hudson/model/Run.html
        return currentBuild.rawBuild.getCause(TimerTriggerCause) != null
    }

    @SuppressWarnings("unused")
    static boolean isUserIdTriggered(currentBuild) {
        // rawBuild is of type http://javadoc.jenkins-ci.org/hudson/model/Run.html
        return currentBuild.rawBuild.getCause(UserIdCause) != null
    }

    static String getBuildUserId(currentBuild) {
        return currentBuild.rawBuild.getCause(UserIdCause)?.getUserId()
    }

    static String getBuildUserEmail(currentBuild) {
        String buildUserId = getBuildUserId(currentBuild)
        String buildUserEmail = null
        if (buildUserId != null) {
            User u = User.get(buildUserId)
            def userEmail = u.getAllProperties().find { it.class.name == 'hudson.tasks.Mailer$UserProperty' }
            buildUserEmail = userEmail?.getAddress() ?: "${getBuildUser()}@zkb.ch"
        }
        return buildUserEmail
    }

    @Deprecated
    static boolean gitChangelogContainsCommentPattern(currentBuild, String commentPattern) {
        String pattern = commentPattern + '[\\s]*?'
        if (currentBuild.changeSets.isEmpty()) {
            return false
        } else if (currentBuild.changeSets.get(0) instanceof GitChangeSetList) {
            if (currentBuild.changeSets.get(0).getLogs().isEmpty()) {
                return false
            } else {
                return currentBuild.changeSets.get(0).getLogs().get(0).comment.matches(pattern)
            }
        } else {
            throw new Exception('Works for Git only.')
        }
    }

    @Deprecated
    static boolean gitChangelogContainsFile(currentBuild, String fileName) {
        if (currentBuild.changeSets.isEmpty()) {
            return false
        } else if (currentBuild.changeSets.get(0) instanceof GitChangeSetList) {
            // A GitChangeSetList is: List of changeset that went into a particular build
            // So we need to only fetch the latest one
            if (currentBuild.changeSets.get(0).getLogs().isEmpty()) {
                return false
            } else {
                GitChangeSetList changeSetList = currentBuild.changeSets.get(0)
                def gitChangeSets = changeSetList.getLogs()
                return !gitChangeSets.findAll { changeSet ->
                    return changeSet.getAffectedFiles().find {
                        gitChangeSetPath -> return gitChangeSetPath.getPath().matches(fileName)
                    }
                }.isEmpty()
            }
        } else {
            throw new Exception('Works for Git only.')
        }
    }

    static boolean gitChangelogContainsAuthorName(currentBuild, String authorName) {
        if (currentBuild.changeSets.isEmpty()) {
            return false
        } else if (currentBuild.changeSets.get(0) instanceof GitChangeSetList) {
            // A GitChangeSetList is: List of changesets that went into a particular build
            // So we need to only fetch the latest one
            if (currentBuild.changeSets.get(0).getLogs().isEmpty()) {
                return false
            } else {
                GitChangeSetList changeSetList = currentBuild.changeSets.get(0)
                List<GitChangeSet> gitChangeSets = changeSetList.getLogs()
                return !gitChangeSets.findAll { changeSet ->
                    return changeSet.getAuthorName() == authorName
                }.isEmpty()
            }
        } else {
            throw new Exception('Works for Git only.')
        }
    }


    static String getDownloadUrl(Map params = [:]) {
        // https://nexus.prod.zkb.ch/service/rest/v1/search/assets?sort=version&direction=desc&repository=snapshots&group=ch.zkb.sbatp.network&name=sbatp-network&maven.baseVersion=PROD.0.1-SNAPSHOT
        def groupId = getOrThrowException(params, 'groupId')
        def artifactId = getOrThrowException(params, 'artifactId')
        def version = getOrThrowException(params, 'version')
        def fileEnding = getOrThrowException(params, 'fileEnding')
        def nexusBaseUrl = params.get("nexusBaseUrl", 'https://nexus.prod.zkb.ch')
        def repository = params.get('repository', '')
        if (repository.isEmpty()) {
            repository = version.toUpperCase().endsWith('-SNAPSHOT') ? 'snapshots' : 'releases'
        }
        def versionParam = repository == 'snapshots' ? "maven.baseVersion=${version}" : "version=${version}"
        def urlAsString = "${nexusBaseUrl}/service/rest/v1/search/assets?sort=version&direction=desc&repository=${repository}&group=${groupId}&name=${artifactId}&$versionParam"
        def response = new JsonSlurper().parseText(new URL(urlAsString).text)
        // def jsonAsText = new JsonBuilder(response).toPrettyString()
        def items = response.items.findAll { it.downloadUrl.endsWith(fileEnding) }
        if (items.isEmpty()) {
            throw new Exception("Unable to find a $fileEnding artifact for $urlAsString")
        } else {
            return items.first().downloadUrl
        }
    }

    static List<String> getVersionsForMavenArtifact(Map params = [:]) {
        List<String> repositories = params.get('repositories', ['snapshots', 'releases'])
        if (params.containsKey('repository')) {
            repositories.clear()
            repositories.add(params.get('repository'))
        }
        def groupId = getOrThrowException(params, 'groupId')
        def artifactId = getOrThrowException(params, 'artifactId')
        def nexusBaseUrl = params.get('nexusBaseUrl', 'https://nexus.prod.zkb.ch')
        List<String> artifactVersions = []
        repositories.each { repository ->
            def url = "${nexusBaseUrl}/repository/${repository}/${groupId.replaceAll('\\.', '/')}/${artifactId}/maven-metadata.xml"
            try {
                def mavenMetaData = new XmlSlurper().parse(url)
                mavenMetaData.versioning.versions.version.each { currentVersion -> artifactVersions.add(currentVersion as String) }
            } catch (Exception e) {
                println "There was an error fetching maven metadata for ${groupId} ${artifactId}: ${e.getMessage()}"
            }
        }
        return VersionUtils.sortVersions(artifactVersions)
    }

    /**
     * Returns a parameters choice friendly formatted string of versions.
     *
     */
    static String getVersionsAsChoiceParam(Map params = [:]) {
        List<String> versionList = getVersionsForMavenArtifact(params)
        return versionList.join('\n')
    }

    static String getOrThrowException(Map params, String key) {
        if (params.containsKey(key)) {
            return params.get(key)
        } else {
            throw new Exception("Missing parameter key " + key)
        }
    }
}
