# PipelineHelper

## Methods

### getScmExtensions

By default in pipelines SCM checkout is done automatically. If you want to have more control about it, e.g. for incremental builds you might want to 
use this method.

#### Parameters

* Map (optional), with following keys
    * `referenceRepo` - String (optional, defaults to null), reference repository location
    * `cleanBeforeCheckout` - Boolean (optional, defaults to true), whether to perform a git clean before building

#### Example

**Use case:** Enable incremental builds for a Gradle project, but do a full build at noon and midnight.

```groovy
@Library('zkb-pipeline-library') _

import ch.zkb.jenkins.pipeline.lib.PipelineHelper

pipeline {
    // For even better performance we would make this project sticky to certain slave...
    agent any
    
    options {
        gitLabConnection('Gitlab')
        skipDefaultCheckout() // To control when incremental/full builds are performed
    }
    
    triggers {
        // No matter whether there were SCM changes, build the project twice a day.
        cron('H 12,23 * * *')
        gitlab(triggerOnPush: true, triggerOnMergeRequest: true, branchFilterType: 'All')
    }
    
    stages {
        stage('Git') {
          steps {
            checkout([
                    $class                           : 'GitSCM',
                    branches                         : scm.branches,
                    doGenerateSubmoduleConfigurations: scm.doGenerateSubmoduleConfigurations,
                    extensions                       : PipelineHelper.getScmExtensions([cleanBeforeCheckout: PipelineHelper.isTimerTriggered(currentBuild)]),
                    userRemoteConfigs                : scm.userRemoteConfigs
            ])
          }
        }
        
        stage('Build'){
            steps {
                  sh './gradlew assemble'
            }
        }
    }
}

```

### isTimerTriggered

Returns whether this build was triggered by the pipeline cron trigger.

#### Parameters

* `currentBuild` (see [global variable reference](https://jenkins.io/doc/book/pipeline/getting-started/#global-variable-reference))

#### Example
```groovy
@Library('zkb-pipeline-library') _

import ch.zkb.jenkins.pipeline.lib.PipelineHelper

pipeline {
    agent any
    stages {
        stage('Test'){
            when {
             expression { return PipelineHelper.isTimerTriggered(currentBuild) }   
            }
            steps {
                  sh 'echo Dummy build step in progress...'
            }
        }
    }
}
```

### isUserIdTriggered

Returns whether this build was manually triggered by a Jenkins user.

#### Parameters

* `currentBuild` (see [global variable reference](https://jenkins.io/doc/book/pipeline/getting-started/#global-variable-reference))

#### Example
```groovy
@Library('zkb-pipeline-library') _

import ch.zkb.jenkins.pipeline.lib.PipelineHelper

pipeline {
    agent any
    stages {
        stage('Test'){
            when {
             expression { return PipelineHelper.isUserIdTriggered(currentBuild) }   
            }
            steps {
                  sh 'echo Dummy build step in progress...'
            }
        }
    }
}
```

### getBuildUserId

Returns the user id as String if this build was manually triggered by a Jenkins user, otherwise null.

#### Parameters

* `currentBuild` (required, see [global variable reference](https://jenkins.io/doc/book/pipeline/getting-started/#global-variable-reference))

### getBuildUserEmail

Returns the users email address as String if this build was manually triggered by a Jenkins user, otherwise null.

#### Parameters

* `currentBuild` (required, see [global variable reference](https://jenkins.io/doc/book/pipeline/getting-started/#global-variable-reference))

### gitChangelogContainsCommentPattern

:warning: **This method is deprecated**, use the built in condition, for more information check the example below or the [pipeline syntax documentation](https://jenkins.io/doc/book/pipeline/syntax/#when).

#### Example
```
@Library('zkb-pipeline-library') _
import ch.zkb.jenkins.pipeline.lib.PipelineHelper

pipeline {

    agent { label 'linux' }

    stages {
        stage('Build') {
            when {
                not {
                    anyOf {
                        changelog '^Add release notes'
                        changelog '^\\[Gradle Release Plugin\\].*$' // Another example with escaping...
                        changeset 'Readme.md'
                        expression { return PipelineHelper.gitChangelogContainsAuthorName(currentBuild, 'Jenkins') }
                    }
                }
            }
            steps {
                sshagent(['gitlab-0779-slk']) {
                    gitCheckoutBranch()
                    sh 'date >> Readme.md'
                    gitCommit([message         : 'Add release notes',
                               files           : 'Readme.md',
                               doPush          : true])
                    gitCreateTag("test-tag-${new Date().format('dd-MM-yyyy-HH-mm-ss')}-${new Random().nextInt()}")
                }
            }
        }
    }
    
    post {
        always {
            cleanWs()
        }
    }
}
```

### gitChangelogContainsFile

:warning: **This method is deprecated**, use the built in condition, for more information check the example below or the [pipeline syntax documentation](https://jenkins.io/doc/book/pipeline/syntax/#when).

#### Example

See [example for gitChangelogContainsCommentPattern](PipelineHelper.md#example-3)

### gitChangelogContainsAuthorName

Searches through the Git commits for this builds (if any) and returns whether it contains changes for given file name.

#### Parameters

* `currentBuild` (required, see [global variable reference](https://jenkins.io/doc/book/pipeline/getting-started/#global-variable-reference))
* `authorName` - String (required) - authors name, e.g. 'Jenkins' or 'Andi Büchler'

#### Example

See [example for gitChangelogContainsCommentPattern](PipelineHelper.md#example-3)


### getDownloadUrl

Returns the download url as a string for given artifact.

#### Parameters

* Map, with following keys
    * `groupId` - String (required)
    * `artifactId` - String (required)
    * `version` - String (required)
    * `fileEnding` - String (required)
    * `nexusBaseUrl` - String (optional), defaults to 'https://nexus.prod.zkb.ch'


#### Example

```
@Library('zkb-pipeline-library') _
import ch.zkb.jenkins.pipeline.lib.PipelineHelper

pipeline {

    agent { label 'linux' }

    parameters {
        choice(name: 'TEST_ARTIFACT_VERSION',
               choices: "${lib.ch.zkb.jenkins.pipeline.lib.PipelineHelper.getVersionsAsChoiceParam([repositories: ['thirdparty'], groupId:  'org.gradle', artifactId:  'gradle'])}",
               description: 'Version to download'
        )
    }
    
    stages {
        stage('Download Something') {
            steps {
              sh """
              wget -o gradle-${params.TEST_ARTIFACT_VERSION}.zip \
                    ${lib.ch.zkb.jenkins.pipeline.lib.PipelineHelper.getDownloadUrl([repository: 'thirdparty', groupId: 'org.gradle', artifactId: 'gradle', version: params.TEST_ARTIFACT_VERSION, fileEnding: '.zip'])}
              test -f gradle-${params.TEST_ARTIFACT_VERSION}.zip
              """
            }
        }
    }
}
```

### getVersionsForMavenArtifact

#### Parameters

* Map, with following keys
    * `repository` - String (required)
    * `groupId` - String (required)
    * `artifactId` - String (required)
    * `nexusBaseUrl` - String (optional), defaults to 'https://nexus.prod.zkb.ch'
    
#### Example

See [example for getDownloadUrl](PipelineHelper.md#example-4)

### getVersionsAsChoiceParam

Parameter choice friendly string of versions.

#### Parameters

* Map, with following keys
    * `repositories` - List<String> (optional)
    * `groupId` - String (required)
    * `artifactId` - String (required)
    * `nexusBaseUrl` - String (optional), defaults to 'https://nexus.prod.zkb.ch'
    
#### Example
    
See [example for getDownloadUrl](PipelineHelper.md#example-4)