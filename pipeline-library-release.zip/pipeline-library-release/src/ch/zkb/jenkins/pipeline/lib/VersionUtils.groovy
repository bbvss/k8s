package ch.zkb.jenkins.pipeline.lib


import java.util.regex.Matcher
import java.util.regex.Pattern

/**
 * Compare version strings.
 *
 * This class can be useful if you have a reasonable versioning schema like described in https://www.semver.org.
 * There are also some other schemas covered here, here's an example:
 *
 * <code>
 *     final String[] correctSortedVersions = [
 *             "5.8",
 *             "5.7",
 *             "2.0.102",
 *             "2.0.0",
 *             "2.0.0-M2",
 *             "2.0.0-M1",
 *             "2.0.0-SNAPSHOT",
 *             "1.0.1",
 *             "1.0"
 *     ]
 * </code>
 *
 *  For a full specification, check the tests under src/test/groovy.
 *
 */
class VersionUtils {

    static final int REVERSE_ORDER = -1
    static final int IS_EQUALS = 0
    static final int IS_GREATER = 1
    static final int IS_SMALLER = -1
    static final Pattern justNumbers
    static final Pattern numbersAtEnd
    static final Pattern numbersAndSomething
    static final Pattern numbersAndOptionalSomething
    static final Pattern justNumbersAndDots
    static final Pattern numberDotsAndPostfix
    static final Comparator<String> versionComparator = { v1, v2 -> compareVersions(v1, v2) }

    static {
        justNumbers = Pattern.compile("\\d+")
        numbersAtEnd = Pattern.compile("(\\D)*(\\d)+\$")
        numbersAndSomething = Pattern.compile("(\\d+)(.*)")
        numbersAndOptionalSomething = Pattern.compile("(\\d+)(([^0-9])+.+)?")
        justNumbersAndDots = Pattern.compile("(\\d+\\.)++\\d")
        numberDotsAndPostfix = Pattern.compile("(?s)(\\d+)\\.(\\d+)\\.(\\d+)(.*)")
    }

    private VersionUtils() {}


    /**
     * Bubblesort implementation because the Jenkins Groovy implementation overrides list.sort() and @NoCPS did not work
     */
    static sortVersions(List<String> versions) {
        String temp
        for (int i = 1; i < versions.size(); i++) {
            for (int j = 0; j < versions.size() - i; j++) {
                def result = compareVersions(versions[j], versions[j + 1])
                if (result < 0) {
                    temp = versions[j]
                    versions[j] = versions[j + 1]
                    versions[j + 1] = temp
                }

            }
        }
        return versions
    }

    static int compareVersions(String v1, String v2) {
        String version1 = sanitizeVersionString(v1)
        String version2 = sanitizeVersionString(v2)
        if (version1.contains(".") || version2.contains(".")) {
            List<String> version1Parts = new ArrayList<>(Arrays.asList(version1.split("\\.")))
            List<String> version2Parts = new ArrayList<>(Arrays.asList(version2.split("\\.")))
            int maxParts = version1Parts.size() > version2Parts.size() ? version1Parts.size() : version2Parts.size()
            List<String> listToPad = version1Parts.size() == maxParts ? version2Parts : version1Parts
            for (int i = listToPad.size(); i < maxParts; i++) {
                listToPad.add("0")
            }
            assert version1Parts.size() == version2Parts.size()
            for (int i = 0; i < maxParts; i++) {
                int partComparison = compareVersionPart(version1Parts.get(i), version2Parts.get(i))
                if (partComparison != IS_EQUALS) {
                    return partComparison
                }
            }
            return IS_EQUALS
        } else if (justNumbers.matcher(version1).matches() && justNumbers.matcher(version2).matches()) {
            return Integer.valueOf(version1) <=> Integer.valueOf(version2)
        } else {
            return compareNumbersAndOptionalSomething(version1, version2)
        }
    }

    static String sanitizeVersionString(String versionString) {
        versionString = versionString.trim()
        versionString.replace('\n', '')
        versionString.replace('\r', '')
        return versionString
    }

    static int compareVersionPart(String part1, String part2) {
        int compareResult
        if (justNumbers.matcher(part1).matches() && justNumbers.matcher(part2).matches()) {
            compareResult = Integer.valueOf(part1) <=> Integer.valueOf(part2)
        } else {
            compareResult = compareNumbersAndOptionalSomething(part1, part2)
        }
        return sanitizeComparisionResult(compareResult)

    }

    static int compareNumbersAndOptionalSomething(String part1, String part2) {
        int compareResult
        Matcher matcherPart1 = numbersAndOptionalSomething.matcher(part1)
        Matcher matcherPart2 = numbersAndOptionalSomething.matcher(part2)
        if (numbersAndOptionalSomething.matcher(part1).matches() && numbersAndOptionalSomething.matcher(part2).matches()) {
            matcherPart1.find()
            matcherPart2.find()
            String numberPart1 = matcherPart1.group(1)
            String numberPart2 = matcherPart2.group(1)
            int numberComparison = Integer.valueOf(numberPart1) <=> Integer.valueOf(numberPart2)
            if (numberComparison == IS_EQUALS) {
                String part1Suffix = matcherPart1.groupCount() > 2 ? matcherPart1.group(2) : ""
                part1Suffix = part1Suffix == null ? "" : part1Suffix
                String part2Suffix = matcherPart2.groupCount() > 2 ? matcherPart2.group(2) : ""
                part2Suffix = part2Suffix == null ? "" : part2Suffix
                if (part1Suffix.isEmpty() && !part2Suffix.isEmpty()) {
                    compareResult = IS_GREATER
                } else if (part2Suffix.isEmpty() && !part1Suffix.isEmpty()) {
                    compareResult = IS_SMALLER
                } else {
                    compareResult = compareConsideringMilestoneAndSnapshots(part1Suffix, part2Suffix)
                }
            } else {
                compareResult = numberComparison
            }
        } else {
            compareResult = sanitizeComparisionResult(part1.compareToIgnoreCase(part2) * REVERSE_ORDER)
        }
        return compareResult
    }

    /**
     * Special case handling e.g. for M1 vs SNAPSHOT or M1 vs M2.
     */
    static int compareConsideringMilestoneAndSnapshots(String part1Suffix, String part2Suffix) {
        int compareResult
        if (Character.isDigit(part1Suffix.charAt(part1Suffix.length() - 1)) && Character.isDigit(part2Suffix.charAt(part2Suffix.length() - 1))) {
            String part1SuffixWithoutEnd = part1Suffix.replaceAll("\\d+\$", "")
            String part2SuffixWithoutEnd = part1Suffix.replaceAll("\\d+\$", "")
            if (part1SuffixWithoutEnd == part2SuffixWithoutEnd) {
                Matcher m1 = numbersAtEnd.matcher(part1Suffix)
                Matcher m2 = numbersAtEnd.matcher(part2Suffix)
                m1.find()
                m2.find()
                compareResult = Integer.valueOf(m1.group(2)) <=> Integer.valueOf(m2.group(2))
            } else {
                compareResult = part1Suffix.compareToIgnoreCase(part2Suffix) * REVERSE_ORDER
            }
        } else {
            compareResult = part1Suffix.compareToIgnoreCase(part2Suffix) * REVERSE_ORDER
        }
        return compareResult
    }

    static int sanitizeComparisionResult(int compareResult) {
        if (compareResult == 0) return IS_EQUALS
        if (compareResult >= 1) return IS_GREATER
        return IS_SMALLER
    }
}
