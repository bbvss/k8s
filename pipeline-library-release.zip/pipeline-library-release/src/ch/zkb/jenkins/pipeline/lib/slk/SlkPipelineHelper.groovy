package ch.zkb.jenkins.pipeline.lib.slk

class SlkPipelineHelper {

    /**
     * Hardcoded algorithm to make pipeline jobs executions sticky on a certain slave by using the branch name. Assumes
     * branches are named according to SLK naming conventions.
     *
     * @param branchName
     * @return Returns one of the slk slaves (number and prefix are hardcoded)
     */
    static def branchToSlaveName(branchName) {
        def noOfSlaves = 15
        def slavePrefix = 'cje2-slave-'
        def branchShort = branchName.replaceAll("^slk-[0-9]{2,2}\\.[0-9]{1,2}.*/feat", "feat")
        def hashCode = Math.abs(branchShort.hashCode()) % noOfSlaves
        def slaveNo = hashCode + 1
        return "${slavePrefix}${slaveNo}"
    }
}


