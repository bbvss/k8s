package ch.zkb.jenkins.pipeline.lib

import org.testng.Assert
import org.testng.annotations.BeforeTest
import org.testng.annotations.Test

class PipelineHelperTest {


    @BeforeTest
    void beforeTest() {
    }

    @Test
    void noVersionFound() {
        def versions = PipelineHelper.getVersionsForMavenArtifact([repository: 'thirdparty', groupId: 'ch.zkb.kukomm.elena', artifactId: 'kukomm-elena-app'])
        Assert.assertEquals(versions.size(), 0, "If there are no versions return an empty list.")
    }

    @Test
    void groupOrArtifactIdNotFound() {
        def versions = PipelineHelper.getVersionsForMavenArtifact([repository: 'thirdparty', groupId: 'org.gradle', artifactId: 'DOES_NOT_EXIST'])
        Assert.assertEquals(versions.size(), 0, "If there is no such artifactId just return an empty list")
        versions = PipelineHelper.getVersionsForMavenArtifact([repository: 'thirdparty', groupId: 'org.doesnotexist', artifactId: 'gradle'])
        Assert.assertEquals(versions.size(), 0, "If there is no such groupId just return an empty list.")
    }

    @Test
    void mavenRepositoryDoesNotExist() {
        def versions = PipelineHelper.getVersionsForMavenArtifact([repository: 'nonExistingNexusMavenRepo', groupId: 'org.gradle', artifactId: 'gradle'])
        Assert.assertEquals(versions.size(), 0, "If there is no such repository just return an empty list.")
    }


    @Test
    void grapVersionsFromArtifactThatDoesExist() {
        List<String> eBankingVersions = PipelineHelper.getVersionsForMavenArtifact([repository: 'releases', groupId: 'ch.zkb.slv.onba', artifactId: 'onba-web'])
        Assert.assertTrue(eBankingVersions.size() > 0, "It should be possible to find versions for onba-web")
    }


    @Test
    void debug() {
        println PipelineHelper.getVersionsAsChoiceParam([repositories: ['releases','snapshots'], groupId: 'ch.zkb.kukomm.elena', artifactId: 'kukomm-elena-app'])
    }
}
