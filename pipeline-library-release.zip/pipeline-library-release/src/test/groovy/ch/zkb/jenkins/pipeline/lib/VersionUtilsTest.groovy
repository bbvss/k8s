package ch.zkb.jenkins.pipeline.lib

import org.testng.annotations.BeforeTest
import org.testng.annotations.Test

import static org.testng.Assert.assertEquals

class VersionUtilsTest {

    /**
     * Some of the entries contain leading/trailing spaces or carriage return or line feeds.
     */
    final List<List<String>> correctlySortedVersionSets = [
            [
                    "5.8\n",
                    "5.7",
                    "2.0.102\r",
                    "2.0.0",
                    "2.0.0-M2",
                    "2.0.0-M1",
                    "2.0.0-SNAPSHOT ",
                    "1.0.1",
                    "1.0"
            ],
            [
                    ' 1.0.36-SNAPSHOT',
                    '1.0.35',
                    ' 1.0.35-SNAPSHOT',
                    '1.0.34',
                    '1.0.34-SNAPSHOT',
                    '1.0.33',
                    '1.0.33-SNAPSHOT',
                    '1.0.24',
                    '1.0.23',
                    '1.0.22',
                    '1.0.22-SNAPSHOT\r',
                    '1.0.15',
                    '1.0.14',
                    '1.0.13',
                    '1.0.10',
                    '1.0.10-SNAPSHOT',
                    '1.0.9',
                    '1.0.8',
                    '1.0.4',
                    '1.0.3',
                    '1.0.2',
                    '1.0.0',
                    '1.0.0-SNAPSHOT\r',
                    '0.0.9',
                    '0.0.9-SNAPSHOT',
                    '0.0.1',
                    '0.0.1-SNAPSHOT'
            ]
    ]

    final List<List<String>> randomizedVersionSets = []


    @BeforeTest
    void beforeTest() {
        int max = 1, min = -1
        Random random = new Random()
        Comparator randomlyMessUpOrder = { v1, v2 -> random.nextInt((max - min) + 1) + min }
        correctlySortedVersionSets.each { correctlySortedVersions ->
            List<String> randomizedVersions = []
            randomizedVersions.addAll(correctlySortedVersions.clone() as List<String>)
            randomizedVersions.sort(randomlyMessUpOrder)
            randomizedVersionSets.add(randomizedVersions)
            assertEquals(randomizedVersions.size(), correctlySortedVersions.size(), "Test data setup broken.")
        }
        assertEquals(randomizedVersionSets.size(), correctlySortedVersionSets.size(), "Test data setup broken")
    }

    @Test
    void crazyVersioning() {
        assertEquals(VersionUtils.compareVersions("Z", "a"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("88.0.0-M2", "88.0.BUILD3"), VersionUtils.IS_GREATER, "This is not intuitive - so we'll document it here.")
        assertEquals(VersionUtils.compareVersions("88-SNAPSHOT", "4"), VersionUtils.IS_GREATER)
    }

    @Test
    void compareNumbersOnly() {
        assertEquals(VersionUtils.compareVersions("12", "22"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("88", "4"), VersionUtils.IS_GREATER)
        assertEquals(VersionUtils.compareVersions("1.0.2", "1.1.10"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("1.1.1", "1.1.10"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("1.10.2", "1.1.10"), VersionUtils.IS_GREATER)
    }

    @Test
    void mixNumbersAndNumbersWithOptionalSomething() {
        assertEquals(VersionUtils.compareVersions("12", "12-m2"), VersionUtils.IS_GREATER)
        assertEquals(VersionUtils.compareVersions("88.0.0-SNAPSHOT", "88"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("88.0.0-SNAPSHOT", "88.0.BUILD-789"), VersionUtils.IS_GREATER)
    }

    @Test
    void compareSnapshots() {
        assertEquals(VersionUtils.compareVersions("1.0.0-SNAPSHOT", "1.0.0-SNAPSHOT"), VersionUtils.IS_EQUALS)
        assertEquals(VersionUtils.compareVersions("1.1-SNAPSHOT", "1.0.1-SNAPSHOT"), VersionUtils.IS_GREATER)
        assertEquals(VersionUtils.compareVersions("1.1.0-SNAPSHOT", "1.0.1-SNAPSHOT"), VersionUtils.IS_GREATER)
        assertEquals(VersionUtils.compareVersions("1.0.0-SNAPSHOT", "1.0.1-SNAPSHOT"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("1.0-SNAPSHOT", "1.0.1-SNAPSHOT"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("1-SNAPSHOT", "1.0.1-SNAPSHOT"), VersionUtils.IS_SMALLER)
    }

    @Test
    void releaseVsSnapshot() {
        assertEquals(VersionUtils.compareVersions("1.0.0-SNAPSHOT", "1.0.0"), VersionUtils.IS_SMALLER, "Same numbers so snapshot is smaller than release.")
        assertEquals(VersionUtils.compareVersions("1.0.0", "1.0.0-SNAPSHOT"), VersionUtils.IS_GREATER, "Same numbers so snapshot is smaller than release.")
        assertEquals(VersionUtils.compareVersions("1.0.0", "1.0.1-SNAPSHOT"), VersionUtils.IS_SMALLER, "Snapshot has higher minor version there is greater.")
    }

    @Test
    void differentLengths() {
        assertEquals(VersionUtils.compareVersions("1.0", "1.0.1"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("2.0.0", "2.0.102"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("2.0.102", "2.0.0"), VersionUtils.IS_GREATER)
        assertEquals(VersionUtils.compareVersions("5.3", "3"), VersionUtils.IS_GREATER)
        assertEquals(VersionUtils.compareVersions("5.3", "3.0.0"), VersionUtils.IS_GREATER)
        assertEquals(VersionUtils.compareVersions("1.0", "1.0.199-SNAPSHOT"), VersionUtils.IS_SMALLER)
        assertEquals(VersionUtils.compareVersions("1.0", "1.0.0"), VersionUtils.IS_EQUALS)
        assertEquals(VersionUtils.compareVersions("1", "1.0.0.0.0.0.0"), VersionUtils.IS_EQUALS)
        assertEquals(VersionUtils.compareVersions("1.0.1-M1", "1.0.1-SNAPSHOT"), VersionUtils.IS_GREATER)
        assertEquals(VersionUtils.compareVersions("1.0.1-M1", "1.0.1-M2"), VersionUtils.IS_SMALLER)
    }

    @Test
    void compareMileStoneVersions() {
        assertEquals(VersionUtils.compareVersions("1.0.1-M1", "1.0.1-M2"), VersionUtils.IS_SMALLER)
    }

    @Test
    void ignoreCaseInEnding() {
        assertEquals(VersionUtils.compareVersions("1.0.1-M1", "1.0.1-m1"), VersionUtils.IS_EQUALS)
        assertEquals(VersionUtils.compareVersions("1.0.2-M1", "1.0.1-m1"), VersionUtils.IS_GREATER)
    }

    @Test
    void sortVersionList() {
        for (int i = 0; i < correctlySortedVersionSets.size(); i++) {
            List<String> actualVersionsOrder = randomizedVersionSets.get(i).clone()
            VersionUtils.sortVersions(actualVersionsOrder)
            List<String> expectedVersionOrder = correctlySortedVersionSets.get(i)
            compareOrderOfList(actualVersionsOrder, expectedVersionOrder)
        }
    }

    private void compareOrderOfList(List<String> actualOrder, List<String> expectedOrder) {
        assertEquals(actualOrder.size(), expectedOrder.size(), "Test setup broken")
        for (int i = 0; i < actualOrder.size(); i++) {
            String versionActual = actualOrder[i]
            String versionExpected = expectedOrder[i]
            assertEquals(versionActual, versionExpected, String.format("Wrong order entry was %s but should be %s", versionActual, versionExpected))
        }
    }
}
