#!/usr/bin/env groovy

def call(String branchPattern) {
    def doesMatch = false
    try {
        doesMatch = env.BRANCH_NAME ==~ branchPattern
    }catch(err){
        echo "currentBranchMatches(): the '${branchPattern}' is not valid."
    }
    return doesMatch
}
