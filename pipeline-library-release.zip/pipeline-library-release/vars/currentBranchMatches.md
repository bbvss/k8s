# currentBranchMatches

Returns whether the current branch matches given regular expression.

## Parameters

A single string (required) containing the regular expression.

## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent any
    stages {

        stage('Build') {
            steps {
                // Upload snapshots to Nexus when building on the master branch
                mvn currentBranchMatches('master') ? '-U clean deploy' : '-U clean package'
            }
        }
    }
}

```
