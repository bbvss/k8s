#!/usr/bin/env groovy

def call(Map params = [:]) {
    //  The environment variable BRANCH_NAME is set for multibranch pipelines but not for others.
    if(env.BRANCH_NAME == null || env.BRANCH_NAME.isEmpty()){
        error 'gitCheckoutBranch: for NON multibranch pipelines you need to specify the branch name or set an the env variable BRANCH_NAME'
    } else {
        // BRANCH_NAME is a default global variable during job execution and points to branch name of the current build.
        String branchName = params.get('branchName', env.BRANCH_NAME)
        sh "git fetch && git checkout -f ${branchName}"
    }
}
