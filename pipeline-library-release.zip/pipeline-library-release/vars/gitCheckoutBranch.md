# gitCheckoutBranch

Checkout a Git branch. By default Jenkins will checkout a specific commit (sha1) which results in detached head. So to be able to commit and push you 
need to checkout a branch first.

> :warning: For **non** multibranch pipelines you need to specify the branch name or set an environment variable named BRANCH_NAME that points to the 
> branch you want to checkout.

## Parameters

* Map (optional), with following keys
    * `branchName` - String (optional, but see warning above)

## Example

```groovy

@Library('zkb-pipeline-library') _
import ch.zkb.jenkins.pipeline.lib.PipelineHelper

pipeline {
    agent any
    
    options {
      timeout(time: 30, unit: 'MINUTES')
    }
    
    parameters {
        booleanParam(name: 'RELEASE', description: 'Build a release', defaultValue: false)
        password(name: 'nexusUsernameToken', defaultValue: '', description: 'Nexus Username Token - required when releasing')
        password(name: 'nexusPasswordToken', defaultValue: '', description: 'Nexus Password Token - required when releasing')
    }
    
    stage('Update Release Notes') {
        when {
            // The gitCommit below will trigger a GitLab webhook to fire which will trigger another Jenkins build... So you need to make sure to 
            // not create and endless build loop.
            not {
                allOf {
                    expression { return PipelineHelper.gitChangelogContainsCommentPattern(currentBuild, '^Add release notes') }
                    expression { return PipelineHelper.gitChangelogContainsFile(currentBuild, 'README.md') }
                    expression { return PipelineHelper.gitChangelogContainsAuthorName(currentBuild, 'Jenkins') }
                }
            }
        }
        steps {
            // Notice the when condition of this stage!
            sshagent(['gitlab-9999-myapp']) {
                gitCheckoutBranch()
                sh "echo 'Update release notes' >> README.md"
                gitCommit([message         : 'Add release notes',
                           files           : 'README.md',
                           doPush          : true])
            }
        }
    }
}

```