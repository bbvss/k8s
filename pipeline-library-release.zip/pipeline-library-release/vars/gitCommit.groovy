#!/usr/bin/env groovy
import ch.zkb.jenkins.pipeline.lib.PipelineHelper

/**
 * In Git the committer/author of a commit is just meta-data. If you really want to verify them you need to cryptographically sign
 * your commits. See https:git-scm.com/book/en/v2/Git-Tools-Signing-Your-Work
 *
 * Nevertheless we can follow the same standards in the CI environment as we do during development. Regarding traceability there are two aspects
 * when using the Maven Release Plugin:
 *
 * - who was performing the Git commit through the plugin
 * - who uploaded the artifact to Nexus through the plugin
 *
 * The best we can do in regards to traceability is to:
 *
 * - set the git author and committer to the logged in Jenkins user
 * - when using a technical user to publish to nexus - include the Jenkins user name in the commit message
 * - or even better: use Nexus username and password tokens
 *
 */
def call(Map params = [:]) {

    String commitMessage = params.get('message', '')
    String files = params.get('files', '-a')
    // BRANCH_NAME is a default global variable during job execution and points to branch name of the current build.
    String branchName = params.get('branchName', "${BRANCH_NAME}")
    boolean doPush = params.get('doPush', false)

    if (commitMessage.isEmpty()) {
        error 'gitCommit: Commit message missing!'
    }

    // The Git committer is always:
    String committerUserId = 'Jenkins'
    String commiterUserEmail = 'jenkins@zkb.ch'
    // Either use the current logged-in user or either set what is specified via the params or use the default.
    String buildUserId = currentBuild.rawBuild.getCause(Cause.UserIdCause)?.getUserId()
    String buildUserEmail = PipelineHelper.getBuildUserEmail(currentBuild)

    if (buildUserId == null) {
        buildUserId = params.get('gitAuthorName', committerUserId)
        buildUserEmail = params.get('gitAuthorEmail', commiterUserEmail)
    }

    wrap([$class: 'MaskPasswordsBuildWrapper']) {
        withEnv(["GIT_COMMITTER_NAME=${committerUserId}",
                 "GIT_COMMITTER_EMAIL=${commiterUserEmail}",
                 "GIT_AUTHOR_NAME=${buildUserId}",
                 "GIT_AUTHOR_EMAIL=${buildUserEmail}"
        ])
                {
                    // Prevent detached head by checking out the branch explicitly instead of the commit sha1,
                    // since we're going to make modifications and commit them through the release plugin.
                    sh "git commit -m '${commitMessage}' ${files} ${doPush ? " && git push origin ${branchName}" : ''}"
                }
    }
}
