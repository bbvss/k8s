# gitCommit

Commit files and optionally push them.

> :warning: Since projects are usually built on Git pushes, you need to make sure to **not** create an endless loop. Make sure to properly skip these 
> builds by setting [when](https://jenkins.io/doc/book/pipeline/syntax/#when) conditions, like shown in the example below!

This pipeline makes it easier to commit and push files in Jenkins, because

* Jenkins will checkout specific commit (sha1) which results in detached head
* Git committer/authors are not automatically properly set

## Parameters

* Map (optional), with following keys
    * `message` - String (required)
    * `files` - String (optional), defaults to '-a' - this means that all changed files that are already tracked by git will be committed.
    * `doPush` - String (optional), defaults to false
    * `gitAuthorName` - String (optional), if the build was triggered by a user will use the users name, otherwise 'Jenkins'
    * `gitAuthorEmail` - String (optional), if the build was triggered by a user will use the users email, otherwise 'jenkins@zkb.ch'

## Example

```groovy

@Library('zkb-pipeline-library') _
import ch.zkb.jenkins.pipeline.lib.PipelineHelper

pipeline {
    agent any
    
    options {
      timeout(time: 30, unit: 'MINUTES')
    }
    
    parameters {
        booleanParam(name: 'RELEASE', description: 'Build a release', defaultValue: false)
        password(name: 'nexusUsernameToken', defaultValue: '', description: 'Nexus Username Token - required when releasing')
        password(name: 'nexusPasswordToken', defaultValue: '', description: 'Nexus Password Token - required when releasing')
    }
    
    stage('Update Release Notes') {
        when {
            // The gitCommit below will trigger a GitLab webhook to fire which will trigger another Jenkins build... So you need to make sure to 
            // not create and endless build loop.
            not {
                allOf {
                    expression { return PipelineHelper.gitChangelogContainsCommentPattern(currentBuild, '^Add release notes') }
                    expression { return PipelineHelper.gitChangelogContainsFile(currentBuild, 'README.md') }
                    expression { return PipelineHelper.gitChangelogContainsAuthorName(currentBuild, 'Jenkins') }
                }
            }
        }
        steps {
            // Notice the when condition of this stage!
            sshagent(['gitlab-9999-myapp']) {
                gitCheckoutBranch()
                sh "echo 'Update release notes' >> README.md"
                gitCommit([message         : 'Add release notes',
                           files           : 'README.md',
                           doPush          : true])
            }
        }
    }
}

```