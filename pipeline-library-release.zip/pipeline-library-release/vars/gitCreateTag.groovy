#!/usr/bin/env groovy
import ch.zkb.jenkins.pipeline.lib.PipelineHelper

def call(String tagName, Map params = [:]) {

    if(tagName == null || tagName.isEmpty()){
        error 'gitCreateTag: The parameter tagName is required!'
    }

    def buildUserId = PipelineHelper.getBuildUserId(currentBuild) ?: 'Jenkins'
    def buildUserEmail = PipelineHelper.getBuildUserEmail(currentBuild) ?: 'jenkins@zkb.ch'

    def message = params.get('message')
    if (message == null) {
        def user = buildUserEmail ?: buildUserId
        def now = new Date().format('dd.MM.yyyy HH:mm:ss')
        message = "${user}\n${now}"
    }

    def force = params.get('override', true)

    withEnv(["GIT_AUTHOR_EMAIL=${buildUserEmail}",
             "GIT_COMMITTER_EMAIL=${buildUserEmail}",
             "GIT_AUTHOR_NAME=${buildUserId}",
             "GIT_COMMITTER_NAME=${buildUserId}"]) {
        sh "git tag ${tagName} -m \"${message}\" ${force ? '--force' : ''}"
        sh "git push origin ${tagName} ${force ? '--force' : ''}"
    }
}
