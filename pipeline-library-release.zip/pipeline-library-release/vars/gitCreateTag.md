# gitCreateTag

Creates a git tag and pushes it back to GitLab.

## Parameters

* `tagName` - String (mandatory), name of the tag
* Map (optional), with following keys
    * `message` - String (optional), message of the tag. The default messages consists of the build user and the current date and time.
    * `override` - boolean (optional), if previous tags should be overridden. Default is true.

## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent any
    
    options {
      timeout(time: 30, unit: 'MINUTES')
    }
       
    // Store version to build in env.VERSION. Get it for example by asking the user.
    
    stage('Publish') {
        steps {
            withCredentials([usernamePassword(credentialsId: 'nexus-myapp-deploy', usernameVariable: 'nexus-username', passwordVariable: 'nexus-password')]) {
                sh "./gradlew publish -Pversion=${env.VERSION}"
            }
            
            // only set tag name
            sshagent(credentials: ['gitlab-9999-myapp']) {
                gitCreateTag env.VERSION
            }
            
            // with custom message
            sshagent(credentials: ['gitlab-9999-myapp']) {
                gitCreateTag env.VERSION, [message: 'My own message']
            }
            
            // preventing overriding previous tags
            sshagent(credentials: ['gitlab-9999-myapp']) {
                gitCreateTag env.VERSION, [override: false]
            }
        }
    }
}
```
