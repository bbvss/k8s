#!/usr/bin/env groovy
import ch.zkb.jenkins.pipeline.lib.PipelineHelper

def call(Map pipelineConfig = [:]) {

    def agentLabel = pipelineConfig.get('agentLabel', 'linux')
    def noOfBuildsToKeep = pipelineConfig.get('numOfBuildsToKeep', 10)
    def pipelineTimeoutInMinutes = pipelineConfig.get('pipelineTimeoutInMinutes', 90)
    def waitForQualityGate = pipelineConfig.get('waitForQualityGate', true)
    def sshAgentId = pipelineConfig.get('sshAgentId', 'gitlab-${appId}-xxx')
    def jdkVersion = pipelineConfig.get('jdkVersion', 'OpenJDK 11.0.2 (64-bit)')
    def mainDevelopmentBranch = pipelineConfig.get('mainDevelopmentBranch', 'master')
    def buildTasks = pipelineConfig.get('buildTasks', 'build')
    def releaseTasks = pipelineConfig.get('releaseTasks', "release -Prelease.useAutomaticVersion=true")
    def nexusCredentialsId = pipelineConfig.get('nexusCredentialsId', "nexus-credentials-id-on-jenkins-for-your-project")
    def pipelineLogLevel = pipelineConfig.get('pipelineLogLevel', 'INFO') // DEBUG, INFO, WARN, ERROR

    pipeline {
        agent { label agentLabel }

        parameters {
            booleanParam(name: "CLEAN_WS_BEFORE_BUILD", description: "Clean the workspace before building.", defaultValue: false)
            booleanParam(name: "SONAR", description: "Check to trigger Sonar analysis", defaultValue: false)
            booleanParam(name: "PUBLISH", description: "Publish current version to Nexus.", defaultValue: false)
            booleanParam(name: "RELEASE", description: "Unsnapshot and Publish current version to Nexus then bump version.", defaultValue: false)
        }

        options {
            gitLabConnection('Gitlab')
            buildDiscarder(logRotator(numToKeepStr: "${noOfBuildsToKeep}"))
            timeout(time: pipelineTimeoutInMinutes, unit: 'MINUTES')
            timestamps()
            skipDefaultCheckout true
        }

        environment {
            // https://docs.gradle.org/current/userguide/build_environment.html#sec:configuring_jvm_memory
            JAVA_OPTS = '-Xms1g -Xmx2g -XX:MaxMetaspaceSize=1g -XX:+UseConcMarkSweepGC -XX:+HeapDumpOnOutOfMemoryError -Dfile.encoding=UTF-8'
            BUILD_STD_OPTS = '--continue --stacktrace --profile --no-daemon --parallel --refresh-dependencies --max-workers=8'
            // The below helper method will make sure there are two automagically generated env variables
            // NEXUS_CREDENTIALS_USR and NEXUS_CREDENTIALS_PSW. See https://jenkins.io/doc/book/pipeline/syntax/#environment
            NEXUS_CREDENTIALS = credentials("${nexusCredentialsId}")
            PIPELINE_LOG_LEVEL = "${pipelineLogLevel}"
        }

        triggers {
            // Start to build some when from 19:00 to 03:59. Since 'H H(19-03) * * *' is not a valid expression
            // we use H(07-15) and shift the timezone accordingly to GMT-10. There is currently (May 2019) a
            // Jenkins bug [1] and GMT-10 is not evaluated correctly. A workaround is to use the equivalent timezone
            // from Hawaii [2].
            // [1] https://stackoverflow.com/questions/17195208/schedule-nightly-22-03-build-using-jenkins-and-h-the-hash-symbol/55863237#55863237
            // [2] https://www.worldtimebuddy.com/?pl=1&lid=5856195,110&h=5856195
            cron '''TZ=US/Hawaii
            H H(07-15) * * *'''
        }

        tools {
            jdk "${jdkVersion}"
        }

        stages {

            stage('Prepare') {
                steps {
                    log('DEBUG', "Pipeline configuration: ${pipelineConfig}")
                    log('DEBUG', "Build parameters: ${params}")
                    log('DEBUG', "Build environment: ${env.getEnvironment()}")
                    checkout([
                            $class                           : 'GitSCM',
                            branches                         : scm.branches,
                            doGenerateSubmoduleConfigurations: scm.doGenerateSubmoduleConfigurations,
                            extensions                       : PipelineHelper.getScmExtensions([cleanBeforeCheckout: pipelineConfig.CLEAN_WS_BEFORE_BUILD || PipelineHelper.isTimerTriggered(currentBuild)]),
                            userRemoteConfigs                : scm.userRemoteConfigs
                    ])
                }
            }

            stage('Build') {
                when {
                    not { expression { params.RELEASE } } // Do not call updateGitLabStatus since release would change the sha1 through commits
                }
                steps {
                    updateGitlabStatus([state: 'running'])
                    sh "./gradlew ${BUILD_STD_OPTS} ${buildTasks}"
                }
            }

            stage('Release') {
                when {
                    expression { params.RELEASE }
                }
                steps {
                    // No updateGitlabStatus(state: 'running') here as commit-hash changes during release-build...
                    sshagent([sshAgentId]) {
                        gitCheckoutBranch()
                        // Make sure there are no unpushed commits from previous runs...
                        sh "git reset --hard origin/${BRANCH_NAME} && git clean -fdx"
                        sh "./gradlew ${BUILD_STD_OPTS} ${releaseTasks}"
                    }
                }
            }

            stage('Sonar') {
                when {
                    anyOf {
                        branch "${mainDevelopmentBranch}"
                        expression { params.SONAR }
                    }
                }
                steps {
                    runSonarAnalysis(waitForQualityGate: waitForQualityGate)
                }
            }

            stage('Publish') {
                when {
                    anyOf {
                        expression { params.PUBLISH }
                        branch "${mainDevelopmentBranch}"
                    }
                }
                steps {
                    sh "./gradlew ${BUILD_STD_OPTS} publish"
                }
            }
        }

        post {
            always {
                // Wrap everything before updateGitlabStatus to ensure no exception is thrown and therefore the update of the Gitlab status is never skipped.
                catchError {
                    junit allowEmptyResults: true, testDataPublishers: [[$class: 'ClaimTestDataPublisher']], testResults: '**/build/test-results/test/*Test.xml'
                    checkstyle canComputeNew: false, canRunOnFailed: true, pattern: '**/build/reports/checkstyle/*.xml'
                }
                updateGitlabStatus()
            }
            changed {
                sendMail()
            }
        }
    }

}

