# gradlePipeline

Custom DSL for a standardized multi branch Gradle pipeline. The pipeline executes some extra tasks for the main 
development branch (see parameters below):

* publishes nightly snapshots from the main development branch to Nexus
* performs nightly analysis from the main development branch on Sonar

## Parameters

> :bulb: Valid values for the version of JDK can be found through the [Jenkins Pipeline Snippet Generator](https://cje2.prod.zkb.ch/directive-generator/) 
> by selecting "Tools" and choosing one, the generated snipped will show the correct string for the selected version.

* Map, with following keys (default values for optional keys are defined in [gradlePipeline.groovy](mavenPipeline.groovy))
    * `sshAgentId` - String (required)
    * `nexusCredentialsId` - boolean (required)
    * `jdkVersion` - String (optional, **but highly recommended**)
    * `mainDevelopmentBranch` - String (optional, defaults to 'master')
    * `buildTasks` - String (optional), default is just the standard 'build' task
    * `releaseTasks` - String (optional), the default assumes your build uses the [net.researchgate.release](https://plugins.gradle.org/plugin/net.researchgate.release) plugin
    * `pipelineLogLevel` - String (optional)
    * `agentLabel` - String (optional)
    * `noOfBuildsToKeep` - int (optional)
    * `pipelineTimeoutInMinutes` - int (optional)
    * `waitForQualityGate` - boolean (optional)


## Example

```groovy
@Library('zkb-pipeline-library') _
gradlePipeline([jdkVersion           : 'OpenJDK 11.0.1 (64-bit)',
                mainDevelopmentBranch: 'dev',
                buildTasks           : 'build releaseDocs',
                nexusCredentialsId   : 'nexus-kukomm-deploy',
                sshAgentId           : 'gitlab-100044-kukomm',
                pipelineLogLevel     : 'DEBUG'])
```