#!/usr/bin/env groovy

def call() {
    def shortCommit = ''
    try {
        shortCommit = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").trim()
    } catch (err) {
        echo 'Unable to get last git commit.'
    }
    return shortCommit
}
