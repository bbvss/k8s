# lastGitCommit
   
   Returns the Git short commit id.
   
   ## Example
   
   ```groovy
   @Library('zkb-pipeline-library') _
   
   pipeline {
       agent any
       stages {
   
           stage('Build') {
               steps {
                   setBuildDisplayName("${readMavenPom().artifactId}-${readMavenPom().version} (${lastGitCommit()})")
                   sh "echo Building..."
               }
           }
       }
   }
   
   ```