#!/usr/bin/env groovy

def call(String logLevel = 'INFO', String message) {
    def LOG_LEVELS = ['DEBUG': 0, 'INFO': 1, 'WARN': 2, 'ERROR': 3]
    int pipelineLogLevel = LOG_LEVELS.get(env.PIPELINE_LOG_LEVEL, 0)
    int currentLogLevel = LOG_LEVELS.get(logLevel, 0)
    if (currentLogLevel >= pipelineLogLevel) {
        echo "${logLevel} - ${message}"
    }
}
