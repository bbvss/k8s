#!/usr/bin/env groovy

def call(Map pipelineConfig = [:]) {

    def agentLabel = pipelineConfig.get('agentLabel', 'linux')
    def noOfBuildsToKeep = pipelineConfig.get('numOfBuildsToKeep', 10)
    def pipelineTimeoutInMinutes = pipelineConfig.get('pipelineTimeoutInMinutes', 90)
    def waitForQualityGate = pipelineConfig.get('waitForQualityGate', true)
    def sshAgentId = pipelineConfig.get('sshAgentId', 'gitlab-${appId}-xxx')
    def jdkVersion = pipelineConfig.get('jdkVersion', 'OpenJDK 11.0.2 (64-bit)')
    def mavenVersion = pipelineConfig.get('mavenVersion', 'Maven 3.5.4')
    def mainDevelopmentBranch = pipelineConfig.get('mainDevelopmentBranch', 'master')
    def nodejsVersion = pipelineConfig.get('nodejsVersion', 'NodeJS V12.13.1 - Linux-X64')
    def pipelineLogLevel = pipelineConfig.get('pipelineLogLevel', 'INFO') // DEBUG, INFO, WARN, ERROR
    def verboseBuildName = pipelineConfig.get('verboseBuildName', false)
    def buildStdOpts = pipelineConfig.get('buildStdOpts', '')
    def buildMailRecipients = pipelineConfig.get('buildMailRecipients', '')
    def junitTestResults = pipelineConfig.get('junitTestResults', '**/target/surefire-reports/TEST-*.xml')

    pipeline {

        agent { label agentLabel }

        options {
            gitLabConnection('Gitlab')
            disableConcurrentBuilds()
            buildDiscarder(logRotator(numToKeepStr: "${noOfBuildsToKeep}"))
            timeout(time: pipelineTimeoutInMinutes, unit: 'MINUTES')
            timestamps()
        }

        environment {
            // Workaround for https://issues.jenkins-ci.org/browse/JENKINS-51404
            JENKINS_MAVEN_AGENT_DISABLED = true
            BUILD_STD_OPTS = "--update-snapshots --strict-checksums -T 5 ${buildStdOpts}"
            PIPELINE_LOG_LEVEL = "${pipelineLogLevel}"
        }

        triggers {
            // Start to build some when from 21:00 to 04:59. Since 'H H(21-04) * * *' is not a valid expression
            // we use H(09-16) and shift the timezone accordingly to GMT-10. There is currently (May 2019) a
            // Jenkins bug [1] and GMT-10 is not evaluated correctly. A workaround is to use the equivalent timezone
            // from Hawaii [2].
            // [1] https://issues.jenkins-ci.org/browse/JENKINS-57702
            // [2] https://www.worldtimebuddy.com/?pl=1&lid=5856195,110&h=5856195
            cron '''TZ=US/Hawaii
            H H(09-16) * * *'''
        }

        tools {
            jdk "${jdkVersion}"
            maven "${mavenVersion}"
            nodejs "${nodejsVersion}"
        }

        parameters {
            booleanParam(name: "SONAR", description: "Check to trigger Sonar analysis", defaultValue: false)
            booleanParam(name: "RELEASE", description: "Check to build a release - <b>Note</b>: User-input required!", defaultValue: false)
        }

        stages {

            stage('Build') {
                when {
                    not { expression { params.RELEASE } } // Do not call updateGitLabStatus since release would change the sha1 through commits
                }
                steps {
                    log('DEBUG', "Pipeline configuration: ${pipelineConfig}")
                    log('DEBUG', "Build parameters: ${params}")
                    log('DEBUG', "Build environment: ${env.getEnvironment()}")
                    script {
                        if (verboseBuildName) {
                            setBuildDisplayName("${readMavenPom().version} (#${lastGitCommit()}) - ${env.BUILD_NUMBER}")
                        }
                    }
                    updateGitlabStatus(state: 'running')
                    // When on the main development branch publish the artifacts to nexus (in maven lingo its called deploy)
                    mvn "${BUILD_STD_OPTS} clean ${currentBranchMatches(mainDevelopmentBranch) ? 'deploy' : 'verify'}"
                }
            }

            stage('Sonar') {
                when {
                    anyOf {
                        allOf {
                            branch "${mainDevelopmentBranch}"
                            triggeredBy 'TimerTrigger'
                        }
                        expression { params.SONAR }
                    }
                }
                steps {
                    runSonarAnalysis(waitForQualityGate: waitForQualityGate, buildTool: 'Maven')
                }
            }

            stage('Release') {
                when {
                    allOf {
                        expression { params.RELEASE }
                        anyOf {
                            branch "${mainDevelopmentBranch}"
                            branch 'fix/**'
                        }
                    }
                }
                steps {
                    // No updateGitlabStatus(state: 'running') here as commit-hash changes during release-build...
                    sshagent([sshAgentId]) {
                        performMavenRelease()
                    }
                }
            }

        }

        post {
            always {
                // Wrap everything before updateGitlabStatus to make sure there is never an exception thrown and therefore the update of
                // the Gitlab status is never skipped.
                catchError {
                    // Note: This is required for Jenkins-2 / SLK as of a bug in the Pipeline-Step-Plugin which prevents withMaven() to work correctly
                    // See the Report Publisher chapter on https://wiki.jenkins.io/display/JENKINS/Pipeline+Maven+Plugin
                    junit([allowEmptyResults : true,
                           testDataPublishers: [[$class: 'ClaimTestDataPublisher']],
                           testResults       : "${junitTestResults}"])
                }
                updateGitlabStatus()
                cleanWs()
            }
            changed {
                sendMail([to: "${buildMailRecipients}"])
            }
        }
    }

}

