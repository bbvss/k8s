# mavenPipeline

Custom DSL for a standardized multi branch Maven pipeline. The pipeline executes some extra tasks for the main 
development branch (see parameters below):
                                                         
* publishes nightly snapshots from the main development branch to Nexus
* performs nightly analysis from the main development branch on Sonar

## Parameters

> :bulb: Valid values for the versions of JDK, Maven, etc can be found through the [Jenkins Pipeline Snippet Generator](https://cje2.prod.zkb.ch/directive-generator/) 
> by selecting "Tools" and choosing one, the generated snipped will show the correct string for the selected version.

* Map, with following keys (default values for optional keys are defined in [mavenPipeline.groovy](mavenPipeline.groovy))
    * `sshAgentId` - String (required)
    * `jdkVersion` - String (optional, **but highly recommended**)
    * `mavenVersion` - String (optional, **but highly recommended**)
    * `nodejsVersion` - String (optional, **but highly recommended**)
    * `mainDevelopmentBranch` - String (optional, defaults to 'master')
    * `buildStdOpts` - String (optional), to specify additional properties, e.g. to trigger the use of HSQL database
    * `pipelineLogLevel` - String (optional)
    * `agentLabel` - String (optional)
    * `noOfBuildsToKeep` - int (optional)
    * `pipelineTimeoutInMinutes` - int (optional)
    * `waitForQualityGate` - boolean (optional)
    * `verboseBuildName` - boolean (optional)
    * `junitTestResults` - String (optional)
    * `buildMailRecipients` - String (optional)
    

## Example

```groovy
@Library('zkb-pipeline-library') _
mavenPipeline([jdkVersion           : 'zkb-base-redhat-openjdk 11_latest (64-bit)',
               mavenVersion         : 'Maven 3.6.2',
               nodejsVersion        : 'NodeJS V12.13.1 - Linux-X64',
               mainDevelopmentBranch: 'dev',
               buildStdOpts         : '-Dcfg.includes=hsqldb.properties', // e.g. to run your tests against the HSQL DB....
               waitForQualityGate   : true,
               sshAgentId           : 'gitlab-1659-slk',
               pipelineLogLevel     : 'DEBUG',
               verboseBuildName     : true])
```