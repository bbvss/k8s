#!/usr/bin/env groovy

def call(String mvnArgs, Map params = [:]) {
    
    boolean disableArtifactsPublisher = params.get('disableArtifactsPublisher', true)
    boolean disableDependencyFingerprintPublisher = params.get('disableDependencyFingerprintPublisher', true)
    String mavenSettingsConfig = params.get('mavenSettingsConfig', 'zkb-maven-user-settings')
    String globalMavenSettingsConfig = params.get('globalMavenSettingsConfig', 'zkb-maven-global-settings')

    withMaven(
            options: [
                    artifactsPublisher(disabled: disableArtifactsPublisher),
                    dependenciesFingerprintPublisher(disabled: disableDependencyFingerprintPublisher)
            ],
            mavenSettingsConfig: mavenSettingsConfig,
            globalMavenSettingsConfig: globalMavenSettingsConfig
    ) {
        // Same default behaviour as a standard Jenkins Maven Job which automatically adds -B (batch-mode, do not request user-input)
        // and prevents aborts on first test failure (so unit-tests dont stop the build and build gets unstable instead of failed):
        sh "mvn -B -Dmaven.test.failure.ignore=true ${mvnArgs}"
    }
}
