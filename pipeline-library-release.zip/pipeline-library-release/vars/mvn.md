# mvn

DRY version to invoke maven with the correct settings. Without further configuration assumes that:

* there is a mavenSettingsConfig named 'zkb-maven-user-settings'
* there is a globalMavenSettingsConfig named 'zkb-maven-global-settings'

The first one is defined inside a Jenkins Application folder (you or your CI
guy need to do it), the second one is defined by LISTA on all Jenkins master
instances.

## Parameters

* String (required), for all the Maven command line parameters
* Map (optional), with following keys
    * `disableArtifactsPublisher` - boolean (optional), defaults to true
    * `disableDependencyFingerprintPublisher` - boolean (optional), defaults to true
    * `mavenSettingsConfig` - String (optional), defaults to 'zkb-maven-user-settings'
    * `globalMavenSettingsConfig` - String (optional), defaults to 'zkb-maven-global-settings'
    


## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent any
    stages {

        stage('WITH Custom Maven DSL Step') {
            steps {
                mvn 'clean package'
            }
        }

        stage('WITHOUT Custom Maven DSL Step') {
            steps {
                withMaven(
                        options: [artifactsPublisher(disabled: true), dependenciesFingerprintPublisher(disabled: true)],
                        mavenSettingsConfig: 'zkb-maven-user-settings',
                        globalMavenSettingsConfig: 'zkb-maven-global-settings'
                ) {
                    // Base options like -B (batch-mode) have to be added with every mvn call!
                    sh 'mvn -B -Dmaven.test.failure.ignore=true clean package'
                }
            }
        }
    }
}

```