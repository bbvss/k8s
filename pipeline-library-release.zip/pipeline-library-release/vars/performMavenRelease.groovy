#!/usr/bin/env groovy
import ch.zkb.jenkins.pipeline.lib.PipelineHelper

/**
 * In Git the committer/author of a commit is just meta-data. If you really want to verify them you need to cryptographically sign
 * your commits. See https:git-scm.com/book/en/v2/Git-Tools-Signing-Your-Work
 *
 * Nevertheless we can follow the same standards in the CI environment as we do during development. Regarding traceability there are two aspects
 * when using the Maven Release Plugin:
 *
 * - who was performing the Git commit through the plugin
 * - who uploaded the artifact to Nexus through the plugin
 *
 * The best we can do in regards to traceability is to:
 *
 * - set the git author and committer to the logged in Jenkins user
 * - when using a technical user to publish to nexus - include the Jenkins user name in the commit message
 * - or even better: use Nexus username and password tokens
 *
 */
def call(Map params = [:]) {

    String buildUserId = currentBuild.rawBuild.getCause(Cause.UserIdCause)?.getUserId()
    String buildUserEmail = PipelineHelper.getBuildUserEmail(currentBuild)

    if (buildUserId == null) {
        error 'performMavenRelease: The performMavenRelease pipeline step must only be called from an user triggered build (not through a cron trigger).'
    }

    // Calculate nice default versions, so the user might normally just accept the proposal.
    // If releasing minor versions (x.y.0, usually on master / release branches), increment the minor version
    // If releasing patch-versions (x.y.z, z > 0, usually on bug-fix branches), increment the patch version
    def pomModel = readMavenPom file: 'pom.xml'
    def currentVersion = pomModel.version.replace('-SNAPSHOT', '')
    def nextVersion = pomModel.version
    List parts = currentVersion.tokenize('.')
    if (parts.size() == 3) {
        def minor = parts[1].toInteger()
        def patch = parts[2].toInteger()
        if (patch == 0) {
            // Increment minor version:
            nextVersion = parts[0] + '.' + (minor + 1) + '.' + patch + '-SNAPSHOT'
        } else {
            // Increment path version:
            nextVersion = parts[0] + '.' + minor + '.' + (patch + 1) + '-SNAPSHOT'
        }
    }

    String systemProps = "-DscmCommentPrefix=\"[Released by ${buildUserId}] \""

    String userProvidedReleaseVersion = params.get('releaseVersion', '')
    String userProvidedDevelopmentVersion = params.get('developmentVersion', '')
    // If the version numbers are not provided via the pipeline prompt the user for them.
    if (userProvidedReleaseVersion.isEmpty() && userProvidedDevelopmentVersion.isEmpty()) {
        def inputs = input(message: 'Define versions', parameters: [
                [$class: 'TextParameterDefinition', name: 'ReleaseVersion', defaultValue: currentVersion],
                [$class: 'TextParameterDefinition', name: 'NextDevelopmentVersion', defaultValue: nextVersion]
        ])
        // Mind the space at the beginning!
        systemProps += " -DreleaseVersion=${inputs.ReleaseVersion} -DdevelopmentVersion=${inputs.NextDevelopmentVersion}"
    } else {
        // Mind the space at the beginning!
        systemProps += " -DreleaseVersion=${userProvidedReleaseVersion} -DdevelopmentVersion=${userProvidedDevelopmentVersion}"
    }

    if (params.containsKey('nexusUsernameToken')) {
        // Mind the space at the beginning!
        systemProps += " -Dnexus.username.token=${params.nexusUsernameToken} -Dnexus.password.token=${params.nexusPasswordToken}"

        if (!params.containsKey('mavenSettingsConfig')) {
            // Set default value for maven settings name with property expansion
            params.put('mavenSettingsConfig', 'zkb-maven-user-settings-with-nexus-token-placeholder')
        }
    }

    String mvnOpts = params.get('mavenOpts', '')
    String mvnGoals = "release:prepare release:perform"

    wrap([$class: 'MaskPasswordsBuildWrapper']) {
        withEnv(["GIT_AUTHOR_EMAIL=${buildUserEmail}",
                 "GIT_COMMITTER_EMAIL=${buildUserEmail}",
                 "GIT_AUTHOR_NAME=${buildUserId}",
                 "GIT_COMMITTER_NAME=${buildUserId}"])
                {
                    // Prevent detached head by checking out the branch explicitly instead of the commit sha1,
                    // since we're going to make modifications and commit them through the release plugin.
                    sh "git fetch && git checkout -f ${BRANCH_NAME}"
                    mvn("${systemProps} ${mvnOpts} ${mvnGoals}", params)
                }
    }
}
