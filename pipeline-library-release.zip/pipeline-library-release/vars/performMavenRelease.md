# performMavenRelease

Executes a Maven release by using the Maven Release Plugin. Automatically detects the current pom version
and asks the user for target versions with mostly correct recommendations. This command should be wrapped
with sshagent command as the release-plugin automatically commits and creates a tag in Gitlab.

> :warning: This method waits for user-input if `releaseVersion` or `nextVersion` parameters are not provided and thus blocks an executor.
> So its important to configure a timeout in the options section and make sure it's only triggered manually by a user or mentioned 
> parameters are set.

<br >

> :warning: **Pipelines with updateGitlabStatus() calls**: make sure there is no 'pending' or 'running' status set on GitLab before executing this 
> step. The updateGitlabStatus() calls will always automatically be bound to the _current_ git commit (sha1) and since the maven-release-plugin is 
> going to make git commits itself, any subsequent calls like updateGitlabStatus(state: 'success') would be bound to a different git commit. **The 
> consequence is that any pipeline states reported before would remain as 'pending' or 'running' on GitLab.**

## Prerequisites

* Gitlab Deploy Key with write rights (*which implies that your project uses Git*)
* Jenkins Credentials with this Gitlab Deploy key (scoped to the project folder only!)
* Nexus username and password tokens ([Nexus](https://nexus.prod.zkb.ch/#user/usertoken))

## Parameters

* Map (optional), with following keys
    * `releaseVersion` - String (optional), release version number, **if not specified user input is required!**
    * `developmentVersion` - String (optional), next development version, **if not specified user input is required!**
    * `nexusUsernameToken` - String (optional), Personal Nexus username token
    * `nexusPasswordToken` - String (optional), Personal Nexus password token
    * `disableArtifactsPublisher` - boolean (optional), defaults to true
    * `disableDependencyFingerprintPublisher` - boolean (optional), defaults to true
    * `mavenSettingsConfig` - String (optional), defaults to 'zkb-maven-user-settings-with-nexus-token-placeholder' when providing Nexus 
      username/password tokens, otherwise the defaults of the mvn step are used
    * `globalMavenSettingsConfig` - String (optional), defaults to 'zkb-maven-global-settings'
    * `mavenOpts` - String (optional), additional command line arguments that are passed to mvn, e.g. '-X'

## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent 'linux'
    
    options {
      timeout(time: 30, unit: 'MINUTES')
    }
    
    parameters {
        booleanParam(name: 'RELEASE', description: 'Build a release', defaultValue: false)
        password(name: 'nexusUsernameToken', defaultValue: '', description: 'Nexus Username Token - required when releasing')
        password(name: 'nexusPasswordToken', defaultValue: '', description: 'Nexus Password Token - required when releasing')
    }
    
    stage('Maven Release') {
        when {
            allOf {
                branch 'master'
                expression { return params.RELEASE }
            }
        }
        steps {
            sshagent(['gitlab-9999-myapp']) {
                performMavenRelease([nexusUsernameToken: params.nexusUsernameToken, nexusPasswordToken: params.nexusPasswordToken, mavenOpts: '-X'])
            }
        }
    }
}
```
