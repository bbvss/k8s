#!/usr/bin/env groovy

def call(String propertyName, params = [:]) {
    String wrapperLocation = params.get('wrapperLocation', '.')
    String gradleWrapper = "${wrapperLocation}/gradlew"

    if (propertyName?.isEmpty()) {
        error "You must specify a property name e.g. 'version'"
    }

    if (fileExists(gradleWrapper)) {
        sh(script: "${gradleWrapper} --no-daemon --console=plain -q properties | grep '^${propertyName}' | awk '{ print \$2 }'", returnStdout: true).trim()
    } else {
        // Assume Gradle is in PATH
        try {
            sh(script: "gradle --no-daemon --console=plain -q properties | grep '^${propertyName}' | awk '{ print \$2 }'", returnStdout: true).trim()
        } catch (e) {
            error "Couldn't find a Gradle Wrapper and Gradle is not in the PATH. Either configure Gradle in the tools section or add a Gradle Wrapper."
        }
    }
}
