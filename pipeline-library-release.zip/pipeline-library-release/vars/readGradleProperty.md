# readGradleProperty

Read any Gradle project property like the projects version.

> :bulb: Assumes this is a Gradle project and there is a Gradle Wrapper or gradle is in the PATH.

## Prerequisites

* A Gradle project

## Parameters
* `propertyName` - String (required), property name, e.g 'version'
* Map (optional), with following keys
    * `wrapperLocation` - String (optional), defaults to '.' (the current directory)
## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent any
    
    options {
      timeout(time: 30, unit: 'MINUTES')
    }
    
    parameters {
        booleanParam(name: 'RELEASE', description: 'Build a release', defaultValue: false)
        password(name: 'nexusUsernameToken', defaultValue: '', description: 'Nexus Username Token - required when releasing')
        password(name: 'nexusPasswordToken', defaultValue: '', description: 'Nexus Password Token - required when releasing')
    }
    
    stage('Build') {
        steps {
            echo readGradleProperty('version')
        }
    }
}
```
