#!/usr/bin/env groovy

def call(Map stepParams = [:]) {
    def doWaitForSonarQualityGate = stepParams.get('waitForQualityGate', true)
    def buildTool = stepParams.get('buildTool', 'Gradle')
    log('DEBUG', "runSonarAnalysis running with params: ${stepParams}")

    withSonarQubeEnv('Sonar produktiv') {
        switch (buildTool.toUpperCase()) {
            case 'GRADLE':
                log('DEBUG', "runSonarAnalysis executing Gradle tasks:dependency-check:aggregate sonar:sonar")
                sh "./gradlew ${BUILD_STD_OPTS} dependencyCheckAggregate sonarqube"
                break;
            case 'MAVEN':
                log('DEBUG', "runSonarAnalysis executing Maven goals: dependency-check:aggregate sonar:sonar")
                log('DEBUG', "BUILD_STD_OPTS: ${BUILD_STD_OPTS}")
                mvn "${BUILD_STD_OPTS} dependency-check:aggregate sonar:sonar"
                break;
            default:
                error "Build tool '${buildTool} is not supported. Either use Gradle or Maven."
        }
    }

    if (doWaitForSonarQualityGate) {
        timeout(time: 90, unit: 'MINUTES') {
            sleep(20) // Workaround, see https://community.sonarsource.com/t/waitforqualitygate-timeout-in-jenkins/2116/6
            waitForQualityGate abortPipeline: doWaitForSonarQualityGate
        }
    }
}