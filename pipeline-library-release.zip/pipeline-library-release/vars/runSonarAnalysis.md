# runSonarAnalysis

Can trigger Sonar analysis for Gradle/Maven Java projects.

## Parameters

* Map (optional), with following keys
    * `waitForQualityGate` - boolean (optional, defaults to true)
    * `buildTool` - String (optional, can be either 'Maven' or 'Gradle', defaults to 'Gradle')

## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent 'linux'
      
    stage('Sonar') {
        when {
            anyOf {
                allOf {
                    branch 'master'
                    triggeredBy 'TimerTrigger'
                }
                expression { params.SONAR }
            }
        }
        steps {
            runSonarAnalysis(waitForQualityGate: waitForQualityGate, buildTool: 'Maven')
        }
    }
}
```




