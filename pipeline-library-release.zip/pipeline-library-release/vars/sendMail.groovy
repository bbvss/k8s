#!/usr/bin/env groovy
import hudson.triggers.TimerTrigger

def call(Map params = [:]) {

    String buildResult = currentBuild.currentResult
    Boolean resultChanged = buildResult != currentBuild.previousBuild?.currentResult
    String defaultMessage
    if (buildResult == 'SUCCESS') {
        defaultMessage = resultChanged ? 'Cool, der Build ist wieder erfolgreich!' : 'Der Build ist erfolgreich!'
    } else {
        defaultMessage = resultChanged ? 'Ohje, es scheint, als ob Du den Build kaputt gemacht hast!' : 'Ohje, der Build ist immer noch kaputt!'
    }

    String messageFooter = """

                             <ul>
                                 <li><a href="${env.JOB_URL}">${env.JOB_NAME}</a></li>
                                 <li><a href="${env.BUILD_URL}">Build #${env.BUILD_NUMBER}</a></li>
                                 <li><a href="${env.BUILD_URL}/console">Konsolen Output Build #${env.BUILD_NUMBER}</a></li>
                                 <li>Build Dauer: ~ ${currentBuild.durationString.replace(' and counting', '')}</li>
                             </ul>
"""

    String recipients = params.get('to', '')
    String subject = params.get('subject', "${buildResult}: Job '${env.JOB_NAME} #${env.BUILD_NUMBER}'")
    String message = params.get('message', """
                             Ahoi!
                             <p>
                             ${defaultMessage}
                             </p>
                             Gruess Jenkins
                          """ + messageFooter)
    Boolean attachLog = params.get('attachLog', true)
    Boolean doSendWhenTimerTriggered = params.get('doSendWhenTimerTriggered', true)
    Boolean isTimerTriggered = currentBuild.rawBuild.getCause(TimerTrigger.TimerTriggerCause) != null
    Boolean doSend = isTimerTriggered ? doSendWhenTimerTriggered : true
    if (doSend) {
        emailext(
                subject: subject,
                body: message,
                to: recipients,
                recipientProviders: [culprits(), requestor(), brokenBuildSuspects(), brokenTestsSuspects()],
                mimeType: 'text/html',
                attachLog: attachLog
        )
    }
}

