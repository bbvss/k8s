# sendMail

Sends email with a default text containing links to the Jenkins pipeline job. 
If there are no recipients Jenkins will try to figure out whom to send emails 
to.

> :bulb: Typically emails are sent using a post-conditions. There are various ways of when to send emails, pick the correct
> [post-condition](https://jenkins.io/doc/book/pipeline/syntax/#post) depending on your requirements.

## Parameters

* Map (optional), with following keys
    * `to` - String (optional), recipients separated with whitespace, if **not specified** a set of recipient providers will be used. For details check [the source](sendMail.groovy).
    * `subject` - String (optional)
    * `message` - String (optional), message body supports HTML
    * `attachLog` - Boolean (optional, defaults to true) whether to attach the build log
    * `doSendWhenTimerTriggered` - Boolean (optional, defaults to true), whether to send mails when the build is timer triggered

## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent any
    stages {
        stage('Test'){
            steps {
                  // Randomly fail to trigger different default messages.
                  sh 'date && exit $(( RANDOM % 2 ))'
            }
        }
    }

    post {
        // There are other post sections than changed, but here we will just 
        // send an email whenever the build status changed
        changed {
            sendMail()
            // all custom
            sendMail([to: 'vorname.nachname@zkb.ch', subject: 'Tests sind fehlgeschlagen', message: 'Ahoi<p>Ein Text...</p>', attachLog: false, doSendWhenTimerTriggered: false])
        }
    }
}

```