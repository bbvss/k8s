#!/usr/bin/env groovy

def call(String displayName) {
    if (!displayName?.isEmpty()) {
        currentBuild.displayName = displayName
    } else {
        echo "WARN: setBuildDisplayName was called without an displayName, ignoring it."
    }
}
