# setBuildDisplayName

Sets the display name of the current build.

## Parameters

* String (required), the build dispaly name

## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent any
    stages {

        stage('Build') {
            steps {
                setBuildDisplayName("${readMavenPom().artifactId}-${readMavenPom().version} (${lastGitCommit()})")
                sh "echo Building..."
            }
        }
    }
}

```
