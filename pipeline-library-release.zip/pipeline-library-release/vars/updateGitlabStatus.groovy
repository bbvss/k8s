#!/usr/bin/env groovy

def call(Map params = [:]) {
        String gitLabName = params.get('name', 'Jenkins Build')
        // Relevant GitLab status are either running, success or failed.
        // https://github.com/jenkinsci/gitlab-plugin/blob/master/src/main/java/com/dabsquared/gitlabjenkins/gitlab/api/model/BuildState.java
        String gitLabState = params.get('state', currentBuild.currentResult == 'SUCCESS' ? 'success' : 'failed')
        updateGitlabCommitStatus name: gitLabName, state: gitLabState
}
