# setBuildDisplayName

Sets the GitLab commit status depending on the current build result. 

If you want to use the GitLab feature 
["Only merge when pipeline succeeds"](https://docs.gitlab.com/ce/user/project/merge_requests/merge_when_pipeline_succeeds.html) 
make sure to set the status to 'running' right at the beginning of your first stage and in the post/always section. 

## Example

```groovy
@Library('zkb-pipeline-library') _

pipeline {
    agent any
    stages {
        stage('Build'){
            steps {
                // Setting it to running will allow GitLab merge request viewers to see that there is a build ongoing...
                updateGitlabStatus state: 'running'
                sh "echo Building..."       
            }
        }
    }
    post {
        always {
            catchError {
                junit allowEmptyResults: true, testDataPublishers: [[$class: 'ClaimTestDataPublisher']], testResults: '**/buildDir/test-results/**/*.xml'
                archiveArtifacts allowEmptyArchive: true, artifacts: '**/buildDir/reports/**'
            }
            // Wrap all previous steps in catchError{} block to make sure the pipeline status on GitLab is always updated.
            // Setting the status as the first thing in the "always" section is not always possible, e.g. the junit archive
            // step is setting the build result to unstable when there are any reported test failures so updateGitlabStatus()
            // needs to come afterwards.
            updateGitlabStatus()
        }
    }
}

```
